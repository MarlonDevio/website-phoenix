// Automatisch gegenereerde index.ts
import Home from "./Home/Home";

export {
  Home,
};
